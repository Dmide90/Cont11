// Copyright 2016 Open Source Robotics Foundation, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <chrono>
#include <functional>
#include <memory>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "std_msgs/msg/int8.hpp"

using namespace std::chrono_literals;

/* This example creates a subclass of Node and uses std::bind() to register a
 * member function as a callback from the timer. */

class MinimalPublisher : public rclcpp::Node
{
public:
  MinimalPublisher()
  : Node("minimal_publisher"), count_(0)
  
  {
    int Stop_cmd_ppark_flag
    int Stop_cmd_ppark_flag1;
    int Stop_cmd_ppark_flag2;
    int Stop_cmd_ppark_flag3;
    int Stop_cmd_ppark_flag4;
    publisher_ = this->create_publisher<std_msgs::msg::Int8>("stop_cmd", 10);
    timer_ = this->create_wall_timer(
      500ms, std::bind(&MinimalPublisher::timer_callback, this));
    publisher2_ = this->create_publisher<std_msgs::msg::Int8>("beep", 10);
    

    subscription1_ = this->create_subscription<std_msgs::msg::Int8>(
      "stop_cmd_park", 10, std::bind(&MinimalSubscriber::topic_callback1, this, _1));
  
  
    subscription2_ = this->create_subscription<std_msgs::msg::Int8>(
      "stop_cmd_human", 10, std::bind(&MinimalSubscriber::topic_callback2, this, _1));
  
  
    subscription3_ = this->create_subscription<std_msgs::msg::Int8>(
      "stop_cmd_robot", 10, std::bind(&MinimalSubscriber::topic_callback3, this, _1));
  
  
    subscription4_ = this->create_subscription<std_msgs::msg::Int8>(
      "stop_cmd_belt", 10, std::bind(&MinimalSubscriber::topic_callback4, this, _1));

    
    
  }
  
private:
  void timer_callback()
  {
    if Stop_cmd_ppark_flag1 = 1 
    auto message = std_msgs::msg::Int8();
    message.data = 1;
    RCLCPP_INFO(this->get_logger(), "Publishing: '%s'", message.data.c_str());
    publisher_->publish(message);
  }
   {
    if Stop_cmd_ppark_flag2 = 1 
    auto message = std_msgs::msg::Int8();
    message.data = 1;
    RCLCPP_INFO(this->get_logger(), "Publishing: '%s'", message.data.c_str());
    publisher_->publish(message);
  }
   {
    if Stop_cmd_ppark_flag3 = 1 
    auto message = std_msgs::msg::Int8();
    message.data = 1;
    RCLCPP_INFO(this->get_logger(), "Publishing: '%s'", message.data.c_str());
    publisher_->publish(message);
  }
   {
    if Stop_cmd_ppark_flag4 = 1 
    auto message = std_msgs::msg::Int8();
    message.data = 1;
    RCLCPP_INFO(this->get_logger(), "Publishing: '%s'", message.data.c_str());
    publisher_->publish(message);
  }
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher2_;

  size_t count_;

void topic_callback1(const std_msgs::msg::Int8::SharedPtr msg) const
  {
    Stop_cmd_ppark_flag = msg->data;
    RCLCPP_INFO(this->get_logger(), ": '%s'", msg->data.c_str());
    if msg->data = 0 
    {
      auto message = std_msgs::msg::Int8();
      message.data = 0;
      publisher2_->publish(message);
      
    }
    
  }
  void topic_callback2(const std_msgs::msg::Int8::SharedPtr msg) const
  {
    Stop_cmd_ppark_flag = msg->data;
    RCLCPP_INFO(this->get_logger(), ": '%s'", msg->data.c_str());
    if msg->data = 0 
    {
      auto message = std_msgs::msg::Int8();
      message.data = 0;
      publisher2_->publish(message);
      
    }
    
  }
  void topic_callback3(const std_msgs::msg::Int8::SharedPtr msg) const
  {
    Stop_cmd_ppark_flag = msg->data;
    RCLCPP_INFO(this->get_logger(), ": '%s'", msg->data.c_str());
    if msg->data = 0 
    {
      auto message = std_msgs::msg::Int8();
      message.data = 0;
      publisher2_->publish(message);
      
    }
    
  }
  void topic_callback4(const std_msgs::msg::Int8::SharedPtr msg) const
  {
    Stop_cmd_ppark_flag = msg->data;
    RCLCPP_INFO(this->get_logger(), ": '%s'", msg->data.c_str());
    if msg->data = 0 
    {
      auto message = std_msgs::msg::Int8();
      message.data = 0;
      publisher2_->publish(message);
      
    }
    
  }
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription1_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription2_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription3_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription4_;

};




int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MinimalPublisher>());
  rclcpp::shutdown();
  return 0;
}
