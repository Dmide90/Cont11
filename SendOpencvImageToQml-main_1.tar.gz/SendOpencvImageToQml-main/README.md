# Send-Opencv-Image-To-Qml
Sending Opencv Images(Mat format) or videos to Qml(Qt Quick side) continuously. 

In this project, I created a basic interface. Users can copy video path pr camera index to text field and open the video on Qml Interface. 

# [Youtube Link](https://www.youtube.com/watch?v=-EYldBso0M4)



# SIMPLE RESULT SHOWING:

![Screencast from 31-01-2021 17_23_01](https://user-images.githubusercontent.com/62008886/106387488-0a86c180-63eb-11eb-9df2-3fe63a7410d6.gif)


# SYSTEM ENVIRONMENT

Ubuntu 18.04
Opencv 4.3.0
Qt 5.15
