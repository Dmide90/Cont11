#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "opencvimageprovider.h"
#include "videostreamer.h"
#include <QQmlContext>
#include <QSharedPointer>
#include <QThread>
#include <QImage>
#include "qmlvars.h"
#include "filter.h"

int main(int argc, char *argv[])
{
    qRegisterMetaType< cv::Mat >("cv::Mat");

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    VideoStreamer videoStreamer;
    VideoStreamer videoStreamerResult;

    OpencvImageProvider *liveImageProvider(new OpencvImageProvider);
    OpencvImageProvider *liveImageResultProvider(new OpencvImageProvider);
    QmlVars qmlVars;
    Filter filter;
    QThread fthread;

    filter.moveToThread(&fthread);
    //QObject::connect(&fthread, &QThread::destroyed, &fthread, &QThread::sto)
    fthread.start();

    engine.rootContext()->setContextProperty("VideoStreamer",&videoStreamer);
    engine.rootContext()->setContextProperty("liveImageProvider",liveImageProvider);
    engine.rootContext()->setContextProperty("VideoStreamerResult",&videoStreamerResult);
    engine.rootContext()->setContextProperty("liveImageProviderResult",liveImageResultProvider);
    engine.rootContext()->setContextProperty("QmlVars", &qmlVars);

    engine.addImageProvider("live",liveImageProvider);
    engine.addImageProvider("liveResult",liveImageResultProvider);

    const QUrl url(QStringLiteral("qrc:/main.qml"));

    engine.load(url);

    QObject::connect(&videoStreamer,&VideoStreamer::newImage,liveImageProvider,&OpencvImageProvider::updateImage);
    QObject::connect(&videoStreamerResult,&VideoStreamer::newImage,liveImageResultProvider,&OpencvImageProvider::updateImage);

    QObject::connect(&qmlVars, &QmlVars::startedChanged, &qmlVars, [&filter, &qmlVars](){
        filter.started = qmlVars.started();
        if (qmlVars.started())
            QTimer::singleShot(0, &filter, [&filter](){
                filter.start();
            });
    });
    QObject::connect(&filter, &Filter::sign_stop, &qmlVars, &QmlVars::setStarted);
    QObject::connect(&filter, &Filter::progressChanged, &qmlVars, &QmlVars::setProgress);

    QObject::connect(&filter, &Filter::newImage, &videoStreamerResult, &VideoStreamer::updateImage);
    QObject::connect(&videoStreamer, &VideoStreamer::newMat, &filter, &Filter::setImage);

    return app.exec();
}
