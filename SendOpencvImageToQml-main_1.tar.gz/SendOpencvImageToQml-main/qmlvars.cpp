#include "qmlvars.h"
#include <QDebug>

QmlVars::QmlVars(QObject *parent)
    : QObject{parent}
    , m_started(false)
    , m_progress(0.0)
{
}

bool QmlVars::started() const
{
    return m_started;
}

void QmlVars::setStarted(bool newStarted)
{
    if (m_started == newStarted)
        return;
    m_started = newStarted;
    emit startedChanged(m_started);
}

double QmlVars::progress() const
{
    return m_progress;
}

void QmlVars::setProgress(double newProgress)
{
    if (qFuzzyCompare(m_progress, newProgress))
        return;
    m_progress = newProgress;
    emit progressChanged(m_progress);
}
