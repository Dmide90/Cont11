#ifndef FILTER_H
#define FILTER_H

#include <QObject>
#include <opencv2/highgui.hpp>

class Filter : public QObject
{
    Q_OBJECT
    Q_PROPERTY(double progress READ progress WRITE setProgress NOTIFY progressChanged)
    Q_PROPERTY(cv::Mat image READ image WRITE setImage NOTIFY imageChanged)

public:
    explicit Filter(QObject *parent = nullptr);

public: bool started;

private:
    double m_progress;
    cv::Mat m_image;

public:
    double progress() const;
    void setProgress(double newProgress);

    const cv::Mat &image() const;
    void setImage(const cv::Mat &newImage);

public slots:
    void start();

signals:

    void startedChanged(bool started);
    void progressChanged(double progress);
    void imageChanged();
    void newImage(cv::Mat);
    void sign_stop(bool started);
};

#endif // FILTER_H
