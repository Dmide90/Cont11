#ifndef QMLVARS_H
#define QMLVARS_H

#include <QObject>
#include <QTimer>

class QmlVars : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool started READ started WRITE setStarted NOTIFY startedChanged)
    Q_PROPERTY(double progress READ progress WRITE setProgress NOTIFY progressChanged)

public:
    explicit QmlVars(QObject *parent = nullptr);

private:
    bool m_started;
    double m_progress;

public:
    bool started() const;
    void setStarted(bool newStarted);

    double progress() const;
    void setProgress(double newProgress);

signals:

    void startedChanged(bool tarted);
    void progressChanged(double progress);

private: QTimer timer;
};

#endif // QMLVARS_H
