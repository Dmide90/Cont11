#ifndef VIDEOSTREAMER_H
#define VIDEOSTREAMER_H

#include <QObject>
#include <QTimer>
#include <opencv2/highgui.hpp>
#include <QImage>
#include <iostream>

class VideoStreamer: public QObject
{
    Q_OBJECT
public:
    VideoStreamer();

public slots:
    void openVideoCamera(QString path);
public slots:
    void updateImage(cv::Mat image);

private:
    cv::Mat image;

signals:
    void newImage(QImage &);
    void newMat(cv::Mat image);
};

#endif // VIDEOSTREAMER_H
