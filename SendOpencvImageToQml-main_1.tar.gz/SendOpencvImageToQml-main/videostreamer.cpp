#include "videostreamer.h"
#include <opencv2/opencv.hpp>
#include <QDebug>

VideoStreamer::VideoStreamer()
{
}

void VideoStreamer::openVideoCamera(QString path)
{
    /*if(path.length() == 1)
    cap.open(path.toInt());
    else
    cap.open(path.toStdString());

    //double fps = cap.get(cv::CAP_PROP_FPS);
    //tUpdate.start(1000/fps);
    cap >> frame;*/
    image = cv::imread(path.toStdString());
    if (image.empty())
    {
        qDebug() << "empty!!!";
        std::cout << "!!! Failed imread(): image not found" << std::endl;
        // don't let the execution continue, else imshow() will crash.
        return;
    }
    emit newMat(image);

    QImage img = QImage(
                static_cast<uchar*>(image.data),
                image.cols,
                image.rows,
                static_cast<int>(image.step),
                QImage::Format_RGB888
            ).rgbSwapped();

    emit newImage(img);
}

void VideoStreamer::updateImage(cv::Mat image)
{
    QImage img = QImage(
                static_cast<uchar*>(image.data),
                image.cols,
                image.rows,
                static_cast<int>(image.step),
                QImage::Format_RGB888
            ).rgbSwapped();
    emit newImage(img);
}
