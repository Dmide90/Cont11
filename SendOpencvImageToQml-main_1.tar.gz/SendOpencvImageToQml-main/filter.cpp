#include "filter.h"
#include <QImage>
#include <QException>
#include <QDebug>
#include <opencv2/opencv.hpp>

Filter::Filter(QObject *parent)
    : QObject{parent}
    , started(false)
    , m_progress(0.0)
{
}

double Filter::progress() const
{
    return m_progress;
}

void Filter::setProgress(double newProgress)
{
    if (qFuzzyCompare(m_progress, newProgress))
        return;
    m_progress = newProgress;
    emit progressChanged(m_progress);
}

const cv::Mat &Filter::image() const
{
    return m_image;
}

void Filter::setImage(const cv::Mat &newImage)
{
    if (started) return;
    m_image = newImage;
    emit imageChanged();
}

void Filter::start()
{
    if (!started) return;
    try {
        double fSize = 3.0 * 100.0;
        double fIndex = 0.0;

        auto image = m_image.clone();
        if (image.empty())
        {
            qDebug() << "empty!!!";
            std::cout << "!!! Failed imread(): image not found" << std::endl;
            // don't let the execution continue, else imshow() will crash.
            return;
        }

        for (int i=0; i<100; i++) {
            // Применяем размытие по Гауссу с большим радиусом
            cv::GaussianBlur(image, image, cv::Size(51, 51), 0);
            fIndex += 1.0;
            setProgress(fIndex / fSize);
            if (!started) return;

            // Применяем медианный фильтр с большим размером окна
            cv::medianBlur(image, image, 51);
            fIndex += 1.0;
            setProgress(fIndex / fSize);
            if (!started) return;

            // Применяем билатеральный фильтр с большими параметрами
            //cv::bilateralFilter(image, image, 51, 100, 100);

            // Применяем фильтр Собеля по горизонтали и вертикали
            //cv::Mat sobelX, sobelY;
            //cv::Sobel(image, sobelX, CV_64F, 1, 0, 7);
            //cv::Sobel(image, sobelY, CV_64F, 0, 1, 7);

            // Вычисляем градиент Собеля
            //cv::addWeighted(sobelX, 0.5, sobelY, 0.5, 0, image);

            // Применяем фильтр Лапласа с большим размером ядра
            //cv::Laplacian(image, image, CV_64F, 7);

            // Применяем морфологические операции (открытие и закрытие)
            cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(21, 21));
            cv::morphologyEx(image, image, cv::MORPH_OPEN, kernel);
            cv::morphologyEx(image, image, cv::MORPH_CLOSE, kernel);
            fIndex += 1.0;
            setProgress(fIndex / fSize);
            if (!started) return;
        }

        setProgress(1.0);
        emit sign_stop(false);
        emit newImage(image);
    }  catch (QException e) {
        qDebug() << e.what();
    }
}
