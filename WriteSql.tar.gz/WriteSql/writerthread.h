#ifndef WRITERTHREAD_H
#define WRITERTHREAD_H

#include <QThread>
#include <arraymutex.h>

class WriterThread : public QThread
{
public:
    WriterThread(ArrayMutex *arrayMutex);
public:
    void run() override;
private:
    ArrayMutex *arrayMutex;
};

#endif // WRITERTHREAD_H
