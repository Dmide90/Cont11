#include "writerthread.h"

WriterThread::WriterThread(ArrayMutex *arrayMutex):
    arrayMutex(arrayMutex)
{

}

void WriterThread::run()
{
    const int arraySize = 50;
    for (int i = 0; i < arraySize; ++i)
    {
        arrayMutex->setValue(i, i);
        QThread::msleep(100);
        QThread::currentThread;
    }
}
