#include "arraytosql.h"

ArrayToSql::ArrayToSql(ArrayMutex *arrayMutex):
    arrayMutex(arrayMutex)
{

}

int ArrayToSql::save()
{
    QList<int> array = arrayMutex->getArray();

    // Создание объекта
   QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");


   db.setHostName("hostname");  // Замените на имя хоста PostgreSQL
   db.setDatabaseName("databasename");  // Замените на имя базы данных
   db.setUserName("username");  // Замените на имя пользователя PostgreSQL
   db.setPassword("password");  // Замените на пароль пользователя PostgreSQL

   // Попытка установить соединение
   if (!db.open()) {
       qDebug() << "Ошибка при подключении к базе данных: " << db.lastError().text();
       return 1;
   }

   // Создание объекта для выполнения SQL-запросов
   QSqlQuery query;
   QString createTable = "CREATE TABLE IF NOT EXITS table_name(column_name INTEGER)";
   if (query.exec(createTable))
     {
       qDebug() << "Tablitsa uspesho sozdana";
   }
   else {
       qDebuq() << "Oshibka: " << query.lastError().text();
   }

    for (int i=0; i<array.size(); i++) {

       QString insertQuery = "INSERT INTO your_table (column1) VALUES (:value1)";  // Вместро your_table column нужно свои какие то данные я не создавал в psql

       // Подготовка запроса с параметрами
       query.prepare(insertQuery);
       query.bindValue(":value1", array[i]);


       if (query.exec()) {
           qDebug() << "Данные успешно вставлены";
       } else {
           qDebug() << "Ошибка при вставке данных: " << query.lastError().text();
       }
    }


   db.close();

   return 0;
}
