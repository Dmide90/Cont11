#include <QCoreApplication>
#include <QDebug>
#include "writerthread.h"
#include "arraymutex.h"
#include "arraytosql.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    ArrayMutex array;

    WriterThread thread1(&array);
    WriterThread thread2(&array);

    thread1.start();
    thread2.start();

    thread1.wait();
    thread2.wait();

    ArrayToSql db(&array);
    db.save();


    return a.exec();
}
