#ifndef ARRAYTOSQL_H
#define ARRAYTOSQL_H

#include <QtSql>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include "arraymutex.h"

class ArrayToSql
{
public:
    ArrayToSql(ArrayMutex *arrayMutex);

    int save();
private:
    ArrayMutex *arrayMutex;
};

#endif // ARRAYTOSQL_H
