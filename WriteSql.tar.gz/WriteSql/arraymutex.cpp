#include "arraymutex.h"

ArrayMutex::ArrayMutex()
{

}

void ArrayMutex::setValue(int index, int value)
{
    mutex.lock();
    if (array.size() <= index) {
        array.append(value);
    }
    else {
        array[index] = value;
    }
    mutex.unlock();
}

QList<int> ArrayMutex::getArray()
{
    mutex.lock();
    QList<int> result(array);
    mutex.unlock();
    return result;
}
