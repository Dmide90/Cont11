#ifndef ARRAYMUTEX_H
#define ARRAYMUTEX_H

#include <QMutex>
#include <QList>

class ArrayMutex
{
public:
    ArrayMutex();

    void setValue(int index, int value);
    QList<int> getArray();


private:
    QMutex mutex;
    QList<int> array;
};

#endif // ARRAYMUTEX_H
